from setuptools import setup

setup(
    name="Cycle Graph Detect",
    version="0.1",
    description="this help you to detect cycle graph",
    url="",
    author="Mohammad",
    author_email="mohammadfazel1382@gmail.com",
    license="MIT",
    packages=["graph"],
    zip_safe=False
)